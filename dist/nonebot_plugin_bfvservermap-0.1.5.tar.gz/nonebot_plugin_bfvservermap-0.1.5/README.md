# nonebot-plugin-bfvservermap  
一个基于nonebot2平台的用于查询服务器图池的插件
需要安装[htmlreder](https://github.com/kexue-z/nonebot-plugin-htmlrender)渲染图片
# 安装
___

nb-cli: (推荐)

~~~
nb plugin install nonebot-plugin-bfvservermap
~~~
pip: (需要在pyproject.toml手动导入)
~~~
pip install nonebot-plugin-bfvservermap
~~~
# 命令列表
map= 服务器name


